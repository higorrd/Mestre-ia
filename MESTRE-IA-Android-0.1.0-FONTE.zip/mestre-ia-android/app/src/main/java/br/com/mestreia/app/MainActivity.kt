package br.com.mestreia.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 48, 36, 48)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        root.addView(TextView(this).apply {
            text = "MESTRE IA\nInteligência de mercado"
            textSize = 27f
            setTextColor(0xFF102B50.toInt())
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "VERSÃO 0.1.0 • SIMULAÇÃO\n\nEsta versão é um protótipo. Ainda não recebe cotações reais nem envia ordens à XP."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 32)
        })
        root.addView(Button(this).apply {
            text = "ATIVAR PAINEL FLUTUANTE"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivity(intent)
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                }
            }
        })
        root.addView(Button(this).apply {
            text = "ABRIR PAINEL NOVAMENTE"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) startService(Intent(this@MainActivity, OverlayService::class.java))
            }
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        // O usuário pode voltar das configurações de sobreposição e tocar no botão para iniciar.
    }
}
