# MESTRE IA Android — protótipo 0.1.0

Este é o esqueleto inicial de um aplicativo Android nativo com solicitação de permissão de sobreposição e painel flutuante. O painel informa explicitamente que não há conexão com dados de mercado e não envia ordens.

## Estado atual
- [x] Estrutura Android/Kotlin inicial
- [x] Tela inicial com identidade MESTRE IA
- [x] Solicitação de permissão Android para sobreposição
- [x] Serviço de painel flutuante básico
- [ ] Feed de cotações reais/licenciadas
- [ ] Motor de análise e previsão validado
- [ ] Simulador de carteira (paper trading)
- [ ] Registro de previsões e avaliação de resultados
- [ ] Integração oficial autorizada com a corretora
- [ ] Controles de risco e auditoria de ordens

## Como abrir e compilar
1. Abra a pasta `mestre-ia-android` no Android Studio.
2. Aguarde o Gradle sincronizar (JDK 17 recomendado).
3. Compile em Build > Build APK(s).
4. Instale o APK de depuração no Android para testar o painel.

## Segurança e limitações
Este projeto NÃO é um robô de investimento funcional. Não contém credenciais, conexão com a XP, preços reais, recomendação financeira ou execução de ordens. O painel flutuante exige autorização explícita do Android. Não coloque senhas, tokens ou chaves de corretora no APK; futuras credenciais devem ficar em servidor seguro.

A integração com a XP permanece pendente de documentação oficial, credenciais e autorização para o produto/conta. O desenvolvimento deverá começar com dados históricos ou feed licenciado e simulação sem dinheiro real.

## Gerar o APK pelo GitHub Actions (sem Android Studio no celular)
1. Envie o conteúdo desta pasta para um repositório GitHub (na raiz do repositório devem ficar `app/`, `build.gradle.kts`, `settings.gradle.kts` e `.github/`).
2. Abra a aba **Actions** do repositório e execute **Build MESTRE IA APK** (ou faça push na branch `main`/`master`).
3. Quando terminar com sucesso, abra a execução e baixe o artefato **mestre-ia-debug-apk**.
4. Extraia o ZIP do artefato e instale `app-debug.apk` no Android. Se o Android perguntar, autorize a instalação pelo app usado para abrir o arquivo.

O workflow compila um APK de depuração. Ele não adiciona conexão com a XP nem negociação real; a versão continua sendo apenas um protótipo de painel flutuante em simulação.
